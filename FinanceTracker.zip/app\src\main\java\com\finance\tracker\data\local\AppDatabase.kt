package com.finance.tracker.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.finance.tracker.data.local.converter.Converters
import com.finance.tracker.data.local.dao.BudgetDao
import com.finance.tracker.data.local.dao.CategoryDao
import com.finance.tracker.data.local.dao.TransactionDao
import com.finance.tracker.data.local.entity.BudgetEntity
import com.finance.tracker.data.local.entity.CategoryEntity
import com.finance.tracker.data.local.entity.TransactionEntity
import com.finance.tracker.data.local.entity.TransactionType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [TransactionEntity::class, CategoryEntity::class, BudgetEntity::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao
    abstract fun categoryDao(): CategoryDao
    abstract fun budgetDao(): BudgetDao

    companion object {
        private const val DATABASE_NAME = "finance_tracker_db"

        fun create(context: Context): AppDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                DATABASE_NAME
            )
                .fallbackToDestructiveMigration()
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        val appContext = context.applicationContext
                        CoroutineScope(Dispatchers.IO).launch {
                            seedDefaultCategories(
                                Room.databaseBuilder(
                                    appContext,
                                    AppDatabase::class.java,
                                    DATABASE_NAME
                                ).build()
                            )
                        }
                    }
                })
                .build()
        }

        private suspend fun seedDefaultCategories(database: AppDatabase) {
            val defaultExpenseCategories = listOf(
                CategoryEntity(name = "Food & Dining", icon = "🍽️", colorIndex = 0, type = TransactionType.EXPENSE, isDefault = true),
                CategoryEntity(name = "Transport", icon = "🚗", colorIndex = 1, type = TransactionType.EXPENSE, isDefault = true),
                CategoryEntity(name = "Bills & Utilities", icon = "📄", colorIndex = 2, type = TransactionType.EXPENSE, isDefault = true),
                CategoryEntity(name = "Shopping", icon = "🛍️", colorIndex = 3, type = TransactionType.EXPENSE, isDefault = true),
                CategoryEntity(name = "Entertainment", icon = "🎬", colorIndex = 4, type = TransactionType.EXPENSE, isDefault = true),
                CategoryEntity(name = "Health", icon = "🏥", colorIndex = 5, type = TransactionType.EXPENSE, isDefault = true),
                CategoryEntity(name = "Education", icon = "📚", colorIndex = 6, type = TransactionType.EXPENSE, isDefault = true),
                CategoryEntity(name = "Housing", icon = "🏠", colorIndex = 7, type = TransactionType.EXPENSE, isDefault = true),
                CategoryEntity(name = "Groceries", icon = "🛒", colorIndex = 8, type = TransactionType.EXPENSE, isDefault = true),
                CategoryEntity(name = "Other Expense", icon = "💳", colorIndex = 9, type = TransactionType.EXPENSE, isDefault = true),
            )

            val defaultIncomeCategories = listOf(
                CategoryEntity(name = "Salary", icon = "💼", colorIndex = 0, type = TransactionType.INCOME, isDefault = true),
                CategoryEntity(name = "Freelance", icon = "💻", colorIndex = 1, type = TransactionType.INCOME, isDefault = true),
                CategoryEntity(name = "Investment", icon = "📈", colorIndex = 2, type = TransactionType.INCOME, isDefault = true),
                CategoryEntity(name = "Gifts", icon = "🎁", colorIndex = 3, type = TransactionType.INCOME, isDefault = true),
                CategoryEntity(name = "Other Income", icon = "💰", colorIndex = 4, type = TransactionType.INCOME, isDefault = true),
            )

            defaultExpenseCategories.forEach { database.categoryDao().insert(it) }
            defaultIncomeCategories.forEach { database.categoryDao().insert(it) }
        }
    }
}
