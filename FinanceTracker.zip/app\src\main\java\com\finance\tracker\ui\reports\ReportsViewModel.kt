package com.finance.tracker.ui.reports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.finance.tracker.data.model.CategorySpending
import com.finance.tracker.data.model.TransactionType
import com.finance.tracker.data.repository.BudgetRepository
import com.finance.tracker.data.repository.TransactionRepository
import com.finance.tracker.util.DateUtils
import com.finance.tracker.util.getMonthBoundaries
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject

data class ReportsUiState(
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0,
    val categorySpending: List<CategorySpending> = emptyList(),
    val monthlyIncome: Double = 0.0,
    val monthlyExpense: Double = 0.0,
    val selectedMonth: String = DateUtils.getCurrentMonth(),
    val isLoading: Boolean = true
)

@HiltViewModel
class ReportsViewModel @Inject constructor(
    private val transactionRepository: TransactionRepository,
    private val budgetRepository: BudgetRepository
) : ViewModel() {

    private val _selectedMonth = MutableStateFlow(DateUtils.getCurrentMonth())
    val uiState: StateFlow<ReportsUiState> = _selectedMonth.flatMapLatest { month ->
        val parts = month.split("-")
        val year = parts[0].toInt()
        val monthNum = parts[1].toInt()

        combine(
            transactionRepository.getMonthlyReport(year, monthNum),
            budgetRepository.getExpenseSummaryByCategory()
        ) { report, categorySpending ->
            ReportsUiState(
                totalIncome = report.totalIncome,
                totalExpense = report.totalExpense,
                categorySpending = categorySpending,
                monthlyIncome = report.totalIncome,
                monthlyExpense = report.totalExpense,
                selectedMonth = month,
                isLoading = false
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = ReportsUiState()
    )

    fun setMonth(month: String) {
        _selectedMonth.value = month
    }

    fun goToPreviousMonth() {
        val parts = _selectedMonth.value.split("-")
        var year = parts[0].toInt()
        var month = parts[1].toInt()
        month--
        if (month < 1) { month = 12; year-- }
        _selectedMonth.value = "${year}-${month.toString().padStart(2, '0')}"
    }

    fun goToNextMonth() {
        val parts = _selectedMonth.value.split("-")
        var year = parts[0].toInt()
        var month = parts[1].toInt()
        month++
        if (month > 12) { month = 1; year++ }
        _selectedMonth.value = "${year}-${month.toString().padStart(2, '0')}"
    }
}
