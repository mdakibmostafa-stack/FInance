package com.finance.tracker.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.finance.tracker.ui.dashboard.DashboardScreen
import com.finance.tracker.ui.reports.ReportsScreen
import com.finance.tracker.ui.settings.SettingsScreen
import com.finance.tracker.ui.transactions.AddTransactionScreen
import com.finance.tracker.ui.transactions.TransactionsScreen

@Composable
fun NavGraph(navController: NavHostController, modifier: Modifier = Modifier) {
    NavHost(
        navController = navController,
        startDestination = Screen.Dashboard.route,
        modifier = modifier
    ) {
        composable(Screen.Dashboard.route) {
            DashboardScreen(
                onAddTransaction = { navController.navigate(Screen.AddTransaction.route) },
                onViewAllTransactions = {
                    navController.navigate(Screen.Transactions.route) {
                        popUpTo(Screen.Dashboard.route) { inclusive = false }
                    }
                }
            )
        }

        composable(Screen.Transactions.route) {
            TransactionsScreen(
                onAddTransaction = { navController.navigate(Screen.AddTransaction.route) }
            )
        }

        composable(Screen.Reports.route) {
            ReportsScreen()
        }

        composable(Screen.Settings.route) {
            SettingsScreen()
        }

        composable(Screen.AddTransaction.route) {
            AddTransactionScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
