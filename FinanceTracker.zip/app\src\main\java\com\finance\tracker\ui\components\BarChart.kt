package com.finance.tracker.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun BarChart(
    data: List<BarChartEntry>,
    modifier: Modifier = Modifier,
    maxValue: Double? = null
) {
    if (data.isEmpty()) return

    val maxVal = maxValue ?: data.maxOf { it.value }
    val barColor = MaterialTheme.colorScheme.primary
    val labelColor = MaterialTheme.colorScheme.onSurfaceVariant
    val gridColor = MaterialTheme.colorScheme.outlineVariant

    Column(modifier = modifier) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .padding(start = 32.dp, end = 8.dp, bottom = 24.dp)
        ) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val barCount = data.size
            val barWidth = (canvasWidth / barCount) * 0.6f
            val gap = (canvasWidth / barCount) * 0.4f

            // Grid lines
            for (i in 0..4) {
                val y = canvasHeight - (canvasHeight * i / 4f)
                drawLine(gridColor, Offset(0f, y), Offset(canvasWidth, y), strokeWidth = 0.5f)
                drawContext.canvas.nativeCanvas.drawText(
                    "${(maxVal * i / 4).toInt()}",
                    -28f,
                    y + 4f,
                    android.graphics.Paint().apply {
                        color = labelColor.hashCode()
                        textSize = 24f
                        textAlign = android.graphics.Paint.Align.LEFT
                    }
                )
            }

            // Bars
            data.forEachIndexed { index, entry ->
                val barHeight = if (maxVal > 0) (entry.value / maxVal * canvasHeight).toFloat() else 0f
                val x = index * (barWidth + gap) + gap / 2
                val y = canvasHeight - barHeight
                drawRect(
                    color = barColor.copy(alpha = 0.8f),
                    topLeft = Offset(x, y),
                    size = androidx.compose.ui.geometry.Size(barWidth, barHeight)
                )

                drawContext.canvas.nativeCanvas.drawText(
                    entry.label,
                    x + barWidth / 2,
                    canvasHeight + 20f,
                    android.graphics.Paint().apply {
                        color = labelColor.hashCode()
                        textSize = 22f
                        textAlign = android.graphics.Paint.Align.CENTER
                    }
                )
            }
        }

        // Legend
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            data.forEach { entry ->
                Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                    Text(
                        text = entry.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = labelColor
                    )
                    Text(
                        text = String.format("%.0f", entry.value),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

data class BarChartEntry(
    val label: String,
    val value: Double
)
