package com.finance.tracker.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.finance.tracker.data.model.Budget
import com.finance.tracker.data.model.Category
import com.finance.tracker.data.model.TransactionType
import com.finance.tracker.ui.components.CategoryIcon
import com.finance.tracker.ui.theme.ExpenseRed
import com.finance.tracker.util.CurrencyFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var showAddCategoryDialog by remember { mutableStateOf(false) }
    var showBudgetDialog by remember { mutableStateOf<Long?>(null) }
    var showDeleteCategoryDialog by remember { mutableStateOf<Category?>(null) }
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            // Tabs
            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Categories") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Budgets") }
                )
            }

            when (selectedTab) {
                0 -> CategoriesTab(
                    categories = uiState.categories,
                    onAddCategory = { showAddCategoryDialog = true },
                    onDeleteCategory = { showDeleteCategoryDialog = it }
                )
                1 -> BudgetsTab(
                    budgets = uiState.budgets,
                    onSetBudget = { showBudgetDialog = it }
                )
            }
        }
    }

    if (showAddCategoryDialog) {
        AddCategoryDialog(
            onDismiss = { showAddCategoryDialog = false },
            onSave = { name, icon, type ->
                viewModel.addCategory(name, icon, type)
                showAddCategoryDialog = false
            }
        )
    }

    if (showDeleteCategoryDialog != null) {
        AlertDialog(
            onDismissRequest = { showDeleteCategoryDialog = null },
            title = { Text("Delete Category") },
            text = { Text("Delete \"${showDeleteCategoryDialog?.name}\"?") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteCategoryDialog?.let { viewModel.deleteCategory(it) }
                    showDeleteCategoryDialog = null
                }) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteCategoryDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showBudgetDialog != null) {
        val categoryId = showBudgetDialog
        SetBudgetDialog(
            categoryId = categoryId,
            onDismiss = { showBudgetDialog = null },
            onSave = { amount ->
                viewModel.setBudget(categoryId, amount)
                showBudgetDialog = null
            }
        )
    }
}

@Composable
private fun CategoriesTab(
    categories: List<Category>,
    onAddCategory: () -> Unit,
    onDeleteCategory: (Category) -> Unit
) {
    Column(modifier = Modifier.padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Categories",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = onAddCategory) {
                Icon(Icons.Filled.Add, contentDescription = "Add category")
            }
        }

        Spacer(Modifier.height(8.dp))

        categories.forEach { category ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CategoryIcon(
                        icon = category.icon,
                        colorIndex = category.colorIndex,
                        size = 40
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = category.name,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = if (category.type == TransactionType.INCOME) "Income" else "Expense",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = if (category.isDefault) "Default" else "Custom",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                    if (category.isCustom) {
                        IconButton(onClick = { onDeleteCategory(category) }) {
                            Icon(
                                Icons.Filled.Delete,
                                contentDescription = "Delete",
                                tint = ExpenseRed
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BudgetsTab(
    budgets: List<Budget>,
    onSetBudget: (Long?) -> Unit
) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text(
            text = "Monthly Budgets",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Set spending limits for categories",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(12.dp))

        // Overall budget
        val overallBudget = budgets.find { it.categoryId == null }
        BudgetCard(
            title = "Overall Budget",
            budget = overallBudget?.amount ?: 0.0,
            spent = overallBudget?.spent ?: 0.0,
            onClick = { onSetBudget(null) }
        )

        Spacer(Modifier.height(8.dp))

        Text(
            text = "Per Category",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(8.dp))

        val categoryBudgets = budgets.filter { it.categoryId != null }
        if (categoryBudgets.isEmpty()) {
            Text(
                text = "No category budgets set. Tap a category to set a budget.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(16.dp)
            )
        } else {
            categoryBudgets.forEach { budget ->
                BudgetCard(
                    title = budget.categoryName ?: "Unknown",
                    budget = budget.amount,
                    spent = budget.spent,
                    onClick = { onSetBudget(budget.categoryId) }
                )
                Spacer(Modifier.height(4.dp))
            }
        }
    }
}

@Composable
private fun BudgetCard(
    title: String,
    budget: Double,
    spent: Double,
    onClick: () -> Unit
) {
    val progress = if (budget > 0) (spent / budget).toFloat().coerceIn(0f, 1f) else 0f
    val isOverBudget = spent > budget

    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "${CurrencyFormatter.format(spent)} / ${CurrencyFormatter.format(budget)}",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = progress,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp),
                color = if (isOverBudget) ExpenseRed else MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
            if (isOverBudget) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "⚠ Budget exceeded by ${CurrencyFormatter.format(spent - budget)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = ExpenseRed
                )
            }
        }
    }
}

@Composable
private fun AddCategoryDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, TransactionType) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(TransactionType.EXPENSE) }
    val icons = listOf("🍔", "🚗", "🏠", "🛍️", "🎮", "💊", "📚", "💼", "🎁", "✈️", "🎵", "🐾", "👕", "💻", "🏋️", "☕")
    var selectedIcon by remember { mutableStateOf(icons[0]) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Category") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Category name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                Text("Type", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = selectedType == TransactionType.EXPENSE,
                        onClick = { selectedType = TransactionType.EXPENSE },
                        label = { Text("Expense") }
                    )
                    FilterChip(
                        selected = selectedType == TransactionType.INCOME,
                        onClick = { selectedType = TransactionType.INCOME },
                        label = { Text("Income") }
                    )
                }
                Spacer(Modifier.height(12.dp))
                Text("Icon", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(4.dp))
                LazyColumn(
                    modifier = Modifier.height(120.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(icons.chunked(6)) { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            row.forEach { icon ->
                                Text(
                                    text = icon,
                                    modifier = Modifier
                                        .clickable { selectedIcon = icon }
                                        .padding(4.dp),
                                    style = MaterialTheme.typography.titleLarge
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(name, selectedIcon, selectedType) },
                enabled = name.isNotBlank()
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun SetBudgetDialog(
    categoryId: Long?,
    onDismiss: () -> Unit,
    onSave: (Double) -> Unit
) {
    var amount by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (categoryId == null) "Overall Budget" else "Category Budget") },
        text = {
            OutlinedTextField(
                value = amount,
                onValueChange = { amount = it },
                label = { Text("Monthly budget amount") },
                prefix = { Text("$") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(
                onClick = {
                    amount.toDoubleOrNull()?.let { onSave(it) }
                },
                enabled = amount.toDoubleOrNull() != null
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
