package com.finance.tracker.data.repository

import com.finance.tracker.data.local.dao.BudgetDao
import com.finance.tracker.data.local.dao.CategoryDao
import com.finance.tracker.data.local.dao.TransactionDao
import com.finance.tracker.data.local.entity.BudgetEntity
import com.finance.tracker.data.local.entity.TransactionType
import com.finance.tracker.data.model.Budget
import com.finance.tracker.data.model.CategorySpending
import com.finance.tracker.util.getMonthBoundaries
import dagger.hilt.android.scopes.ViewModelScoped
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import java.util.Calendar
import javax.inject.Inject

@ViewModelScoped
class BudgetRepository @Inject constructor(
    private val budgetDao: BudgetDao,
    private val categoryDao: CategoryDao,
    private val transactionDao: TransactionDao
) {
    fun getBudgetsForMonth(month: String): Flow<List<Budget>> {
        val (startOfMonth, endOfMonth) = getMonthBoundaries()

        return budgetDao.getBudgetsForMonth(month).combine(
            transactionDao.getExpenseSummaryByCategory(startOfMonth, endOfMonth)
        ) { budgets, categorySpending ->
            val spendingMap = categorySpending.associate { it.categoryId to it.total }

            budgets.map { budget ->
                val spent = if (budget.categoryId != null) {
                    spendingMap[budget.categoryId] ?: 0.0
                } else {
                    spendingMap.values.sum()
                }
                val categoryName = if (budget.categoryId != null) {
                    categoryDao.getCategoryById(budget.categoryId)?.name
                } else null

                Budget(
                    id = budget.id,
                    categoryId = budget.categoryId,
                    categoryName = categoryName,
                    amount = budget.amount,
                    spent = spent,
                    month = budget.month
                )
            }
        }
    }

    suspend fun getBudgetByCategory(categoryId: Long, month: String): Budget? {
        val budget = budgetDao.getBudgetByCategory(categoryId, month) ?: return null
        val (startOfMonth, endOfMonth) = getMonthBoundaries()
        val spent = transactionDao.getTotalByTypeAndDate(
            TransactionType.EXPENSE, startOfMonth, endOfMonth
        )
        return Budget(
            id = budget.id,
            categoryId = budget.categoryId,
            amount = budget.amount,
            spent = spent,
            month = budget.month
        )
    }

    fun getExpenseSummaryByCategory(): Flow<List<CategorySpending>> {
        val (startOfMonth, endOfMonth) = getMonthBoundaries()
        return transactionDao.getExpenseSummaryByCategory(startOfMonth, endOfMonth).map { summaries ->
            val totalExpense = summaries.sumOf { it.total }
            summaries.mapNotNull { summary ->
                val category = categoryDao.getCategoryById(summary.categoryId) ?: return@mapNotNull null
                CategorySpending(
                    categoryId = summary.categoryId,
                    categoryName = category.name,
                    categoryIcon = category.icon,
                    categoryColorIndex = category.colorIndex,
                    amount = summary.total,
                    percentage = if (totalExpense > 0) (summary.total / totalExpense).toFloat() else 0f
                )
            }.sortedByDescending { it.amount }
        }
    }

    suspend fun setBudget(categoryId: Long?, amount: Double, month: String) {
        val existing = if (categoryId != null) {
            budgetDao.getBudgetByCategory(categoryId, month)
        } else {
            budgetDao.getOverallBudget(month).firstOrNull()
        }

        if (existing != null) {
            budgetDao.update(existing.copy(amount = amount))
        } else {
            budgetDao.insert(BudgetEntity(
                categoryId = categoryId,
                amount = amount,
                month = month
            ))
        }
    }

    suspend fun deleteBudget(budget: Budget) {
        budgetDao.delete(BudgetEntity(
            id = budget.id,
            categoryId = budget.categoryId,
            amount = budget.amount,
            month = budget.month
        ))
    }
}
