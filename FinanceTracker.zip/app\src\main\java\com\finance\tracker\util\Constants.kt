package com.finance.tracker.util

object Constants {
    const val DEFAULT_CURRENCY = "USD"
    val CATEGORY_COLORS = listOf(
        0xFF4CAF50.toInt(),
        0xFF2196F3.toInt(),
        0xFFFF9800.toInt(),
        0xFFE91E63.toInt(),
        0xFF9C27B0.toInt(),
        0xFF00BCD4.toInt(),
        0xFFFF5722.toInt(),
        0xFF607D8B.toInt(),
        0xFF795548.toInt(),
        0xFF3F51B5.toInt()
    )
}
