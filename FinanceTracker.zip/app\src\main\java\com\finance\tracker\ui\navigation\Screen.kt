package com.finance.tracker.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val title: String) {
    data object Dashboard : Screen("dashboard", "Home")
    data object Transactions : Screen("transactions", "Transactions")
    data object Reports : Screen("reports", "Reports")
    data object Settings : Screen("settings", "Settings")
    data object AddTransaction : Screen("add_transaction", "Add Transaction")
}

fun Screen.iconVector(): ImageVector = when (this) {
    Screen.Dashboard -> Icons.Filled.Home
    Screen.Transactions -> Icons.Filled.SwapHoriz
    Screen.Reports -> Icons.Filled.BarChart
    Screen.Settings -> Icons.Filled.Settings
    Screen.AddTransaction -> Icons.Filled.Home
}

val bottomNavItems = listOf(
    Screen.Dashboard,
    Screen.Transactions,
    Screen.Reports,
    Screen.Settings
)
