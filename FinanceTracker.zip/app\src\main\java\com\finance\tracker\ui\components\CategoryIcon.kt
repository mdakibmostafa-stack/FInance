package com.finance.tracker.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.finance.tracker.util.Constants

@Composable
fun CategoryIcon(
    icon: String,
    colorIndex: Int,
    modifier: Modifier = Modifier,
    size: Int = 44
) {
    val bgColor = if (colorIndex in Constants.CATEGORY_COLORS.indices) {
        Constants.CATEGORY_COLORS[colorIndex]
    } else Constants.CATEGORY_COLORS[0]

    Box(
        modifier = modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(androidx.compose.ui.graphics.Color(bgColor).copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = icon,
            style = MaterialTheme.typography.titleLarge
        )
    }
}
