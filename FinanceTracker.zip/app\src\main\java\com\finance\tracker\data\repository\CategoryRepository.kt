package com.finance.tracker.data.repository

import com.finance.tracker.data.local.dao.CategoryDao
import com.finance.tracker.data.local.entity.CategoryEntity
import com.finance.tracker.data.model.Category
import dagger.hilt.android.scopes.ViewModelScoped
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

@ViewModelScoped
class CategoryRepository @Inject constructor(
    private val categoryDao: CategoryDao
) {
    fun getAllCategories(): Flow<List<Category>> {
        return categoryDao.getAllCategories().map { entities ->
            entities.map { it.toCategory() }
        }
    }

    suspend fun getAllCategoriesList(): List<Category> {
        return categoryDao.getAllCategoriesList().map { it.toCategory() }
    }

    suspend fun getCategoryById(id: Long): Category? {
        return categoryDao.getCategoryById(id)?.toCategory()
    }

    fun getExpenseCategories(): Flow<List<Category>> {
        return categoryDao.getExpenseCategories().map { entities ->
            entities.map { it.toCategory() }
        }
    }

    fun getIncomeCategories(): Flow<List<Category>> {
        return categoryDao.getIncomeCategories().map { entities ->
            entities.map { it.toCategory() }
        }
    }

    suspend fun insert(category: Category): Long {
        return categoryDao.insert(category.toEntity())
    }

    suspend fun update(category: Category) {
        categoryDao.update(category.toEntity())
    }

    suspend fun delete(category: Category) {
        categoryDao.delete(category.toEntity())
    }

    private fun CategoryEntity.toCategory(): Category {
        return Category(
            id = id,
            name = name,
            icon = icon,
            colorIndex = colorIndex,
            type = type,
            isDefault = isDefault,
            isCustom = isCustom
        )
    }

    private fun Category.toEntity(): CategoryEntity {
        return CategoryEntity(
            id = id,
            name = name,
            icon = icon,
            colorIndex = colorIndex,
            type = type,
            isDefault = isDefault,
            isCustom = isCustom
        )
    }
}
