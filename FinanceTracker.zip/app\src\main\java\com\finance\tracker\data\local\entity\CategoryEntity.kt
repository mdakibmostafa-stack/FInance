package com.finance.tracker.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val icon: String = "💰",
    val colorIndex: Int = 0,
    val type: TransactionType = TransactionType.EXPENSE,
    val isDefault: Boolean = false,
    val isCustom: Boolean = false
)
