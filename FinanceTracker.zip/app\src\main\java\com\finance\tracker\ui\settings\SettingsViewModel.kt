package com.finance.tracker.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.finance.tracker.data.model.Budget
import com.finance.tracker.data.model.Category
import com.finance.tracker.data.model.TransactionType
import com.finance.tracker.data.repository.BudgetRepository
import com.finance.tracker.data.repository.CategoryRepository
import com.finance.tracker.util.DateUtils
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val categories: List<Category> = emptyList(),
    val budgets: List<Budget> = emptyList(),
    val currentMonth: String = DateUtils.getCurrentMonth()
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val categoryRepository: CategoryRepository,
    private val budgetRepository: BudgetRepository
) : ViewModel() {

    val uiState: StateFlow<SettingsUiState> = combine(
        categoryRepository.getAllCategories(),
        budgetRepository.getBudgetsForMonth(DateUtils.getCurrentMonth())
    ) { categories, budgets ->
        SettingsUiState(
            categories = categories,
            budgets = budgets,
            currentMonth = DateUtils.getCurrentMonth()
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = SettingsUiState()
    )

    fun addCategory(name: String, icon: String, type: TransactionType) {
        viewModelScope.launch {
            categoryRepository.insert(
                Category(name = name, icon = icon, type = type, isCustom = true)
            )
        }
    }

    fun deleteCategory(category: Category) {
        viewModelScope.launch {
            categoryRepository.delete(category)
        }
    }

    fun setBudget(categoryId: Long?, amount: Double) {
        viewModelScope.launch {
            budgetRepository.setBudget(categoryId, amount, DateUtils.getCurrentMonth())
        }
    }

    fun deleteBudget(budget: Budget) {
        viewModelScope.launch {
            budgetRepository.deleteBudget(budget)
        }
    }
}
