package com.finance.tracker.ui.transactions

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.finance.tracker.data.model.Category
import com.finance.tracker.data.model.Transaction
import com.finance.tracker.data.model.TransactionType
import com.finance.tracker.data.repository.CategoryRepository
import com.finance.tracker.data.repository.TransactionRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class TransactionsUiState(
    val transactions: List<Transaction> = emptyList(),
    val searchQuery: String = "",
    val filterType: TransactionType? = null,
    val isLoading: Boolean = true
)

@HiltViewModel
class TransactionsViewModel @Inject constructor(
    private val transactionRepository: TransactionRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val _filterType = MutableStateFlow<TransactionType?>(null)

    val uiState: StateFlow<TransactionsUiState> = combine(
        transactionRepository.getAllTransactions(),
        _searchQuery,
        _filterType
    ) { transactions, query, filterType ->
        val filtered = transactions.filter { t ->
            (query.isBlank() || t.note.contains(query, ignoreCase = true) ||
                    t.categoryName.contains(query, ignoreCase = true)) &&
                    (filterType == null || t.type == filterType)
        }
        TransactionsUiState(
            transactions = filtered,
            searchQuery = query,
            filterType = filterType
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = TransactionsUiState()
    )

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilterType(type: TransactionType?) {
        _filterType.value = type
    }

    fun deleteTransaction(transaction: Transaction) {
        viewModelScope.launch {
            transactionRepository.delete(transaction)
        }
    }
}

data class AddTransactionUiState(
    val amount: String = "",
    val selectedCategory: Category? = null,
    val categories: List<Category> = emptyList(),
    val type: TransactionType = TransactionType.EXPENSE,
    val date: Long = System.currentTimeMillis(),
    val note: String = "",
    val isSaving: Boolean = false,
    val savedSuccessfully: Boolean = false
)

@HiltViewModel
class AddTransactionViewModel @Inject constructor(
    private val transactionRepository: TransactionRepository,
    private val categoryRepository: CategoryRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AddTransactionUiState())
    val uiState: StateFlow<AddTransactionUiState> = _uiState.asStateFlow()

    init {
        loadCategories()
    }

    private fun loadCategories() {
        viewModelScope.launch {
            val categories = categoryRepository.getAllCategoriesList()
            _uiState.update { it.copy(categories = categories) }
        }
    }

    fun setAmount(amount: String) {
        _uiState.update { it.copy(amount = amount) }
    }

    fun setType(type: TransactionType) {
        _uiState.update { it.copy(type = type, selectedCategory = null) }
        loadCategories()
    }

    fun selectCategory(category: Category) {
        _uiState.update { it.copy(selectedCategory = category) }
    }

    fun setDate(date: Long) {
        _uiState.update { it.copy(date = date) }
    }

    fun setNote(note: String) {
        _uiState.update { it.copy(note = note) }
    }

    fun saveTransaction() {
        val state = _uiState.value
        val amount = state.amount.toDoubleOrNull() ?: return
        val category = state.selectedCategory ?: return

        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            transactionRepository.insert(
                Transaction(
                    amount = amount,
                    type = state.type,
                    categoryId = category.id,
                    date = state.date,
                    note = state.note
                )
            )
            _uiState.update { it.copy(isSaving = false, savedSuccessfully = true) }
        }
    }
}
