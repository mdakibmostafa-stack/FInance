# Finance Tracker - Android Personal Finance App

A simple, clean, and fast personal finance tracker built with **Kotlin** and **Jetpack Compose**.

## Features

- **Dashboard** — View current balance, total income/expenses, and recent transactions at a glance
- **Transactions** — Add, view, search, and filter income/expense entries
- **Categories** — Pre-built categories (Food, Transport, Bills, Salary, etc.) plus custom categories
- **Budget Tracking** — Set monthly budgets per category, track spending progress with visual indicators
- **Reports** — Monthly income vs expense bar charts and spending-by-category pie charts
- **Search & Filters** — Search by keyword, filter by type (income/expense)
- **Dark Mode** — Full Material 3 dark theme support (auto-detects system setting)
- **Offline First** — All data stored locally with Room Database, works completely offline

## Tech Stack

| Component | Library |
|-----------|---------|
| Language | Kotlin |
| UI | Jetpack Compose + Material 3 |
| Architecture | MVVM |
| Database | Room (SQLite) |
| DI | Dagger Hilt |
| Async | Kotlin Coroutines + Flow |
| Navigation | Navigation Compose |

## Project Structure

```
app/src/main/java/com/finance/tracker/
├── data/
│   ├── local/
│   │   ├── entity/          # Room entities (Transaction, Category, Budget)
│   │   ├── dao/             # Data Access Objects
│   │   ├── converter/       # Type converters
│   │   └── AppDatabase.kt   # Room database + seed data
│   ├── repository/          # Repository layer (Transaction, Category, Budget)
│   └── model/               # Domain models
├── di/                      # Hilt dependency injection modules
├── ui/
│   ├── theme/               # Material 3 theme, colors, typography
│   ├── navigation/          # NavGraph and Screen definitions
│   ├── dashboard/           # Dashboard screen + ViewModel
│   ├── transactions/        # Transactions list + Add Transaction screen + ViewModels
│   ├── reports/             # Reports screen + ViewModel
│   ├── settings/            # Settings screen + ViewModel (categories + budgets)
│   └── components/          # Reusable composables (TransactionItem, Charts, Cards)
└── util/                    # Utility classes (CurrencyFormatter, DateUtils)
```

## Setup Instructions

### Prerequisites

- Android Studio Hedgehog (2023.1.1+) or later
- JDK 17+
- Android SDK API 34+

### Steps

1. **Clone or open the project**
   - Open Android Studio
   - Select **File → New → Project from Version Control...** or **File → Open**
   - Navigate to the project root folder

2. **Sync Gradle**
   - Android Studio will automatically detect the Gradle configuration
   - Wait for the **Sync** to complete (may take a few minutes on first run)
   - If prompted, install any missing SDK components

3. **Build & Run**
   - Select a device/emulator (API 26+)
   - Click **Run** (green triangle) or press `Shift + F10`
   - The app will install and launch automatically

### Building from Command Line

```bash
# On Windows (PowerShell)
./gradlew assembleDebug

# On macOS/Linux
./gradlew assembleDebug
```

The APK will be at `app/build/outputs/apk/debug/app-debug.apk`

### Building via GitHub Actions (no local setup needed)

1. Push this repo to GitHub
2. Go to **Actions** tab → **Build APK** workflow
3. Click **Run workflow** (or it triggers automatically on push)
4. Download the APK from the workflow run's **Artifacts**

## Default Categories

**Expense:** Food & Dining, Transport, Bills & Utilities, Shopping, Entertainment, Health, Education, Housing, Groceries, Other Expense

**Income:** Salary, Freelance, Investment, Gifts, Other Income

## Screenshots

| Dashboard | Transactions | Reports | Settings |
|-----------|-------------|---------|----------|
| Balance overview | List + search | Charts | Categories + Budgets |

## License

This project is provided for educational purposes.
