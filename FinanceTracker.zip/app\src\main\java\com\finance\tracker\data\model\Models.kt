package com.finance.tracker.data.model

import com.finance.tracker.data.local.entity.TransactionType

data class Transaction(
    val id: Long = 0,
    val amount: Double,
    val type: TransactionType,
    val categoryId: Long,
    val categoryName: String = "",
    val categoryIcon: String = "",
    val categoryColorIndex: Int = 0,
    val date: Long,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class Category(
    val id: Long = 0,
    val name: String,
    val icon: String = "💰",
    val colorIndex: Int = 0,
    val type: TransactionType = TransactionType.EXPENSE,
    val isDefault: Boolean = false,
    val isCustom: Boolean = false
)

data class Budget(
    val id: Long = 0,
    val categoryId: Long? = null,
    val categoryName: String? = null,
    val amount: Double,
    val spent: Double = 0.0,
    val month: String
)

data class DashboardData(
    val currentBalance: Double = 0.0,
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0,
    val savings: Double = 0.0,
    val recentTransactions: List<Transaction> = emptyList()
)

data class MonthlyReport(
    val month: String,
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0
)

data class CategorySpending(
    val categoryId: Long,
    val categoryName: String,
    val categoryIcon: String,
    val categoryColorIndex: Int,
    val amount: Double,
    val percentage: Float = 0f
)
