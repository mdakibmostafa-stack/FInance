package com.finance.tracker.ui.reports

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.finance.tracker.ui.components.BarChart
import com.finance.tracker.ui.components.BarChartEntry
import com.finance.tracker.ui.components.PieChart
import com.finance.tracker.ui.components.PieChartEntry
import com.finance.tracker.ui.components.StatsCard
import com.finance.tracker.ui.theme.ExpenseRed
import com.finance.tracker.ui.theme.IncomeGreen
import com.finance.tracker.util.CurrencyFormatter
import com.finance.tracker.util.DateUtils
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    viewModel: ReportsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Reports") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            // Month navigation
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.goToPreviousMonth() }) {
                    Icon(Icons.Filled.ChevronLeft, contentDescription = "Previous month")
                }
                Text(
                    text = DateUtils.formatMonthYear(
                        Calendar.getInstance().apply {
                            val parts = uiState.selectedMonth.split("-")
                            set(parts[0].toInt(), parts[1].toInt() - 1, 1)
                        }.timeInMillis
                    ),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = { viewModel.goToNextMonth() }) {
                    Icon(Icons.Filled.ChevronRight, contentDescription = "Next month")
                }
            }

            // Summary cards
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatsCard(
                    title = "Income",
                    amount = CurrencyFormatter.format(uiState.totalIncome),
                    color = IncomeGreen,
                    modifier = Modifier.weight(1f)
                )
                StatsCard(
                    title = "Expenses",
                    amount = CurrencyFormatter.format(uiState.totalExpense),
                    color = ExpenseRed,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(24.dp))

            // Income vs Expense bar chart
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Income vs Expenses",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(16.dp))
                    BarChart(
                        data = listOf(
                            BarChartEntry("Income", uiState.totalIncome),
                            BarChartEntry("Expenses", uiState.totalExpense)
                        )
                    )
                }
            }

            Spacer(Modifier.height(24.dp))

            // Spending by category
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Spending by Category",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(8.dp))

                    if (uiState.categorySpending.isEmpty()) {
                        Text(
                            text = "No expenses this month",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(16.dp)
                        )
                    } else {
                        PieChart(
                            data = uiState.categorySpending.map {
                                PieChartEntry(it.categoryName, it.amount)
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}
