package com.finance.tracker.data.repository

import com.finance.tracker.data.local.dao.CategoryDao
import com.finance.tracker.data.local.dao.TransactionDao
import com.finance.tracker.data.local.entity.CategoryEntity
import com.finance.tracker.data.local.entity.TransactionEntity
import com.finance.tracker.data.model.Category
import com.finance.tracker.data.model.DashboardData
import com.finance.tracker.data.model.MonthlyReport
import com.finance.tracker.data.model.Transaction
import com.finance.tracker.data.model.TransactionType
import com.finance.tracker.util.getMonthBoundaries
import dagger.hilt.android.scopes.ViewModelScoped
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import java.util.Calendar
import javax.inject.Inject

@ViewModelScoped
class TransactionRepository @Inject constructor(
    private val transactionDao: TransactionDao,
    private val categoryDao: CategoryDao
) {
    fun getAllTransactions(): Flow<List<Transaction>> {
        return transactionDao.getAllTransactions().map { entities ->
            entities.map { it.toTransaction() }
        }
    }

    fun getRecentTransactions(limit: Int = 10): Flow<List<Transaction>> {
        return transactionDao.getRecentTransactions(limit).map { entities ->
            entities.map { it.toTransaction() }
        }
    }

    suspend fun getTransactionById(id: Long): Transaction? {
        return transactionDao.getTransactionById(id)?.toTransaction()
    }

    suspend fun insert(transaction: Transaction): Long {
        return transactionDao.insert(transaction.toEntity())
    }

    suspend fun update(transaction: Transaction) {
        transactionDao.update(transaction.toEntity())
    }

    suspend fun delete(transaction: Transaction) {
        transactionDao.delete(transaction.toEntity())
    }

    fun searchTransactions(query: String): Flow<List<Transaction>> {
        return transactionDao.searchTransactions(query).map { entities ->
            entities.map { it.toTransaction() }
        }
    }

    fun getDashboardData(): Flow<DashboardData> {
        val (startOfMonth, endOfMonth) = getMonthBoundaries()
        val (startOfToday, endOfToday) = getDayBoundaries()

        val totalIncomeFlow = transactionDao.observeTotalByTypeAndDate(
            TransactionType.INCOME, startOfMonth, endOfMonth
        )
        val totalExpenseFlow = transactionDao.observeTotalByTypeAndDate(
            TransactionType.EXPENSE, startOfMonth, endOfMonth
        )
        val recentTransactionsFlow = getRecentTransactions(5)

        return combine(totalIncomeFlow, totalExpenseFlow, recentTransactionsFlow) { income, expense, transactions ->
            DashboardData(
                currentBalance = income - expense,
                totalIncome = income,
                totalExpense = expense,
                savings = income - expense,
                recentTransactions = transactions
            )
        }
    }

    fun getTransactionsBetweenDates(startDate: Long, endDate: Long): Flow<List<Transaction>> {
        return transactionDao.getTransactionsBetweenDates(startDate, endDate).map { entities ->
            entities.map { it.toTransaction() }
        }
    }

    fun getTransactionsByTypeAndDate(type: TransactionType, startDate: Long, endDate: Long): Flow<List<Transaction>> {
        return transactionDao.getTransactionsByTypeAndDate(type, startDate, endDate).map { entities ->
            entities.map { it.toTransaction() }
        }
    }

    fun getTransactionsByCategoryAndDate(categoryId: Long, startDate: Long, endDate: Long): Flow<List<Transaction>> {
        return transactionDao.getTransactionsByCategoryAndDate(categoryId, startDate, endDate).map { entities ->
            entities.map { it.toTransaction() }
        }
    }

    fun getMonthlyReport(year: Int, month: Int): Flow<MonthlyReport> {
        val calendar = Calendar.getInstance()
        calendar.set(year, month - 1, 1, 0, 0, 0)
        val startOfMonth = calendar.timeInMillis
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH))
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        val endOfMonth = calendar.timeInMillis

        val incomeFlow = transactionDao.observeTotalByTypeAndDate(TransactionType.INCOME, startOfMonth, endOfMonth)
        val expenseFlow = transactionDao.observeTotalByTypeAndDate(TransactionType.EXPENSE, startOfMonth, endOfMonth)

        return combine(incomeFlow, expenseFlow) { income, expense ->
            MonthlyReport(
                month = "${year}-${month.toString().padStart(2, '0')}",
                totalIncome = income,
                totalExpense = expense
            )
        }
    }

    private fun getDayBoundaries(): Pair<Long, Long> {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        val startOfDay = calendar.timeInMillis
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        val endOfDay = calendar.timeInMillis
        return Pair(startOfDay, endOfDay)
    }

    private suspend fun TransactionEntity.toTransaction(): Transaction {
        val category = categoryDao.getCategoryById(categoryId)
        return Transaction(
            id = id,
            amount = amount,
            type = type,
            categoryId = categoryId,
            categoryName = category?.name ?: "Unknown",
            categoryIcon = category?.icon ?: "❓",
            categoryColorIndex = category?.colorIndex ?: 0,
            date = date,
            note = note,
            createdAt = createdAt
        )
    }

    private fun Transaction.toEntity(): TransactionEntity {
        return TransactionEntity(
            id = id,
            amount = amount,
            type = type,
            categoryId = categoryId,
            date = date,
            note = note,
            createdAt = createdAt
        )
    }
}
